﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExtraCreditGPA
{
    public partial class GPA : Form
    {
        public GPA()
        {
            InitializeComponent();
        }

        //Event Handler to Process input

        private void button1_Click(object sender, EventArgs e)
        {
            string Process = Convert.ToString(txtLastName.Text + "," + "  " + txtFirstName.Text + ";" + "" + txtStudentID.Text);
            string Invalid = "Invalid Entry";
            string LastName = Convert.ToString(txtLastName.Text);
            string FirstName = Convert.ToString(txtFirstName.Text);          

            if (decimal.TryParse(txtStudentID.Text, out decimal StudentID))
            {
                if (decimal.TryParse(txtGPA.Text, out decimal GPA))
                {
                    if //Comment If:  Last Name, First Name, Student ID all have have proper inputs, and GPA has to be between 0 and 4
                    (
                        LastName.Length > 0
                        && FirstName.Length > 0
                        && Convert.ToDecimal(txtStudentID.Text) > 0
                        && Convert.ToDecimal(txtGPA.Text) >= 0
                        && Convert.ToDecimal(txtGPA.Text) <= 4
                    )
                    { //If comment if is True; Then Display Last Name, First name, and Student ID in the label 
                        lblProcess.Text = Process;
                    }
                    else //If comment if is not true, display invalid entry
                    {
                        lblProcess.Text = Invalid;
                    }
                }
                else
                {
                    lblProcess.Text = ("Invalid Entry GPA");
                }
            }
            else
            {
                lblProcess.Text = ("Invalid Entry Student ID");
            }
            
        }

        //Event Handler to clear form
        private void btnClear_Click(object sender, EventArgs e)
        {
            lblProcess.Text = "";
            txtLastName.Text = "";
            txtFirstName.Text = "";
            txtStudentID.Text = "";
            txtGPA.Text = "";
        }


        //Event Handler to close app; 

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
