﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    class Program
    {
        static void Main(string[] args)
        {
            //the ++ adds one could have i=i + 1 or i+=2 or -- to go down
            for (int i = 0; i > -10; i--)
            {
                Console.WriteLine(i);

            }
            Console.ReadKey();
        }
    }
}
