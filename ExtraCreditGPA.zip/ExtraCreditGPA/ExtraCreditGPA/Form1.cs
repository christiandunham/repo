﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExtraCreditGPA
{
    public partial class GPA : Form
    {
        public GPA()
        {
            InitializeComponent();
        }


        //Variable Declaration
        /*
        string LastName = txtLastName.Text();
        char FirstName = Convert.ToChar(txtFirstName.Text);
        int StudentID = Convert.ToDecimal(txtStudentID.Text);
        int GPA = Convert.ToInt64(txtGPA.Text);
(       string TrueMessage = "txtLastName" + "txtFirstName" + "txtStudentID" + "GPA";
        string InvalidMessage = "Invalid Entry";
        */


        





        //Event Handler to close app

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
          
        }



        //Event Handler to Process input

        private void btnProcess_Click(object sender, EventArgs e)
        {
            // string LastName = txtLastName.Text;


           // string StudentID = string.Format("{n2}", "");




        }


        private void button1_Click(object sender, EventArgs e)


        {
            string Process = Convert.ToString(txtLastName.Text + "," + "  " + txtFirstName.Text + ";" + "" + txtStudentID.Text);
            string Invalid = "Invalid Entry";
            string LastName = Convert.ToString(txtLastName.Text);
            string FirstName = Convert.ToString(txtFirstName.Text);
            int StudentID = Convert.ToInt16(txtStudentID.Text);
            decimal GPA = Convert.ToDecimal(txtGPA.Text);


            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtStudentID.Text = "";
            txtGPA.Text = "";


            if 
                (
                
                LastName.Length > 0
                && FirstName.Length > 0
                && StudentID > 0
                && GPA > 0
                )
            {
                lblProcess.Text = Process;

            }


            else
            {
                lblProcess.Text = Invalid;
            }


        }
    }
}
