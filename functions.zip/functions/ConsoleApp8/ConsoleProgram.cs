﻿using System;

namespace ConsoleTest
{
    class Program
    {
        // This in the main function
        static void Main(string[] args)
        {
            DoNothing();
            InputFunction();

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
        //This is the second function
        static void DoNothing()
        {
            Console.WriteLine("This functions does very little!");
        }

        //THis is the third function
        static void InputFunction()
        {
            string textInput;
            string messageReceived;

            Console.WriteLine("Enter text:");
            textInput = Console.ReadLine();

            messageReceived = OutputFunction(textInput);
            Console.WriteLine("The received message is: {0}", messageReceived);
        }

        //This is the fourth function
        static string OutputFunction(string text)
        {
            Console.WriteLine("You wrote: {0}", text);
            string message = "This is a message from the output function.";

            return message;
        }
    }
}