﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AreaAndPerimeter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //This event handler should close the form on click of the exit button
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        /*This event handler should close the form on keydown esc
Code adapted from searching https://Stackoverflow.com/questions/3526752/how-to-make-a-form-close-when-pressing-the-escape-key*/

        private void Form_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }




        //This event handler should operate the calculate button with the pressing of enter
        private void btnCalculate_Enter(object sender, EventArgs e)
        {

            /*Telling calculate button to convert text to decimal 
            decimal Length = Convert.ToDecimal(txtLength.Text);
            decimal Width = Convert.ToDecimal(txtWidth.Text);*/

            //Now doing the math this code does area
            txtArea.Text = Convert.ToString(Convert.ToDecimal(txtLength.Text) * Convert.ToDecimal(txtWidth.Text));
            txtPerimeter.Text = Convert.ToString(Convert.ToDecimal(txtArea.Text) * 2);
            //this code will shift focus if user clicks calculate back to txtLength
            txtLength.Focus();

        }


        //This code should shift focus to txt.length after enter key is pressed
        private void calculate_keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtLength.Focus();
            }
        }
    }
}
