﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            int InputSeconds = 0;

            InputSeconds = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(InputSeconds);

            int InputMinutes = InputSeconds / 60;

            Console.WriteLine(InputMinutes);

            int InputHours = InputMinutes / 60;

            Console.WriteLine(InputHours);

            int InputDays = InputHours / 24;

            Console.WriteLine(InputDays);

            Console.ReadKey();
        }
    }
}