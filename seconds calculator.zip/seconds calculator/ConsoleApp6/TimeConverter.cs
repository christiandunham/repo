﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {

            //Variables
            int InputSeconds = 0;
            int days = 0;
            int hours = 0;
            int minutes = 0;
            int remainder = 0;

            Console.WriteLine("How many seconds ?");
            InputSeconds = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(InputSeconds);

            days = InputSeconds / (60 * 60 * 24);
            remainder = InputSeconds % (60 * 60 * 24);
            hours = remainder / (60 * 60);
            remainder = remainder % (60 * 60);
            minutes = remainder / 60;
            remainder = remainder % 60;

            Console.WriteLine(Convert.ToString(days) + " day(s), " + Convert.ToString(hours) + " hours(s), " + Convert.ToString(minutes) + " minutes(s), and " + Convert.ToString(remainder) + " seconds(s).");

            //Keep the console open
            Console.WriteLine("Press any key to end program.");
            Console.ReadKey();
        }
    }
}